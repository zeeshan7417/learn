
// const users = require('../Model/User_schema');



// exports.updatecolumn = async()=>{

//         try
//         {
//             const updatecolumn = await users.updateMany({}, {$set:{"email": "test@gmail.com"}});
//         console.log(updatecolumn);
//         }
//             catch(error){
//                 res.send(500).json(error);
                
//             }
    
// }



// exports.userdata =async(req,res)=>{
//     try{

//         const fetch_all = await users.find({})
//         if(fetch_all!=''){
//             res.status(200).send({
//                 message: "Data Fetch All",
//                  status :true,
//                  status: 200,
//                  data: fetch_all
//               });
//         }
//     }
//     catch(error){
//         res.status(500).json({'messgae':'some things wrongs'});
//     }
   
        
// }


// exports.userdatabyid= async(req,res)=>{
//     try {
        
//         const databyid = await users.find({_id:req.params.id});
//         console.log(databyid);
//          if(databyid!=''){
//             res.status(200).send({
//                 message: "Data Fetch BY ID",
//                  status :true,
//                  status: 200,
//                  data: databyid
//               });
//          }
//          else{
//             res.status(400).send({
//                 message:"Data Not Found By !",
//                 status:false,
//               });
//          }
  
//     } catch (error) {
//         res.sendStatus(500).json(error);
        
        
//     }


// }


// exports.updateusers =async(req,res)=>{
// try {
//     const update = await users.findByIdAndUpdate(req.params.id, req.body, {
//         new: true,
//         runValidators: true,
//         context: 'query'
//        })

//      console.log(update);

//      res.status(200).send({
//         message:'dataupdated by id',
//         status:true,
//         data:update
//       });
    

// } catch (error) {
//     res.status(500).send({
//         message:error,
//         status:false,
//       });
    
// }

// }



// exports.deletebyuserid = async(req,res)=>{

//     try {
//          const userdelete = await users.deleteOne({_id:req.params.id});
//          res.status(200).json('user has been deleted');
        
        
//     } catch (error) {

//         res.status(500).json(error);
        
//     }
// }




// // exports.upload_image =async()=>{


// // }


