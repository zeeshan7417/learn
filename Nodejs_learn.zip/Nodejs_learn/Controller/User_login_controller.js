const userlogin = require('../Model/User_register_schema');
const bcrypt = require('bcryptjs');

const jwt = require('jsonwebtoken');




exports.login = async (req, res, next) => {


    console.log(req.body);

    if (Object.keys(req.body).length === 0) {
        res.status(404).send({
            message: `all field required`,
            status:80
          });
      }


    try {

        const password = req.body.user_password;
        var user = await userlogin.findOne({ user_email: req.body.user_email }).exec();
    //console.log(user);
            
        if (!user) {
            return res.status(401).json({
                message: "The Email does not exist",
                status: 81
            });
          //  return response.status(400).send({ message: "The Email does not exist" });
        }


        const validPassword = await bcrypt.compare(password, user.user_password);
        if (!validPassword) {
            return res.status(402).json({
                message: "Incorrect User Credentails",
                status: 402
            });
        }

        const theToken = jwt.sign({ _id: user._id }, 'the-super-strong-secrect');

        if (!theToken) {
            return res.status(401).json({
                message: "Invalid Token",
                status: 403
            });

          
        }

const updatecolumn = await userlogin.updateMany({ _id: user._id }, { $set: { "user_token": theToken, user_loginstatus: true }},{ useFindAndModify: false});
      

         

     //   res.cookie("jwttoken",theToken,{expires:new Date(Date.now()+25892000000), httpOnly:true});

        if (updatecolumn) {
                return res.json({
                    message: 'user Login Successfully',
                    data: user,
                    status:200,
                
                });
           }

    }
    catch (error) {

    }
};

