const category = require('../../Model/Category_schema/Category_model');

exports.category_save = async (req, res) => {
    if (Object.keys(req.body).length === 0) {
        return res.json({
            message: 'All Filed Required',
            status: false
        });
    }
    try {

        var cat_slug = await category.findOne({ category_slug: req.body.category_slug });
        if (cat_slug) {

            return res.status(400).json({ message: 'Slug Already Exist', status: 400 });
        }


        const savedata = new category({
            category_name: req.body.category_name,

            category_slug: req.body.category_slug,
            category_descrption: req.body.category_descrption,
            category_parent: req.body.category_parent,
        });

        savedata.save();

        return res.status(200).json({ message: 'success', status: true, data: savedata });
    } catch (error) {

        return res.json({
            message: 'some things wrong',
            error: error,
            status: false
        });

    }


}




exports.fetchcategory = async (req, res) => {

    try {
        var categorydata = await category.find().exec();
        if (categorydata != '') {

            return res.json({
                message: 'success',
                data: categorydata,
                status: true
            });
        }
        else {
            return res.json({
                message: 'Data Not found',
                data: categorydata,
                status: false
            });
        }

    } catch (error) {
        return res.json({
            message: 'some things wrong',
            error: error,
            status: false
        });
    }
}



exports.getsinglecategory = async (req, res) => {
    const id = req.params.id;
    if(!id){

        return res.json({
            message: 'Please Provide ID',
            status: false
        });
    }

 try {
    

     const findata = await category.findById(id);
    // console.log(findata);
       if(findata!=null){
     return res.json({
        message: 'success',
         status: true,
         data:findata,
    });
}
else{

    return res.json({
        message: 'Data Not Found',
         status: false,
         data:'',
    });  
}
    
     
 } catch (error) {
    return res.json({
        message: 'some things wrong',
         error: error,
         status: false,
    });
 }
   
    


}



exports.categoryupdate = async(req,res)=>{

   
    if (Object.keys(req.body).length === 0) {
        res.status(404).send({
            message: `all field required`
          });
      }
    try {

        const id = req.params.id;
       
       const data =   await category.findByIdAndUpdate(id, req.body, { useFindAndModify: false });
       console.log(data);
        if(!data){
            res.status(404).send({
                message: `Cannot update Tutorial with id=${id}. Maybe category was not found!`
              });

        }
        else res.send({ message: "Tutorial was updated successfully." , data :data });
    } catch (error) {
        
    }


}


