var mongoose = require('mongoose');

 const Databaseconnection = async()=>{

        const dbConfigurl = 'mongodb://localhost:27017/project';
        const dbConfigOptions = { useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false};

        try {
          await mongoose.connect(dbConfigurl, dbConfigOptions)

           console.info(`Connected to database on Worker process: ${process.pid}`)
    } catch (error) {
        console.error(`Connection error: ${error.stack} on Worker process: ${process.pid}`)
        process.exit(1)
    }

 


 }
// Databaseconnection();
module.exports = Databaseconnection();


