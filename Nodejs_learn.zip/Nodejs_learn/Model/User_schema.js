// const mongoose = require("mongoose");
// const userdata = mongoose.Schema({
//     name: String,
//      city:String,
//     image:String
// })





// module.exports = mongoose.model("news", userdata);