const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const Userregister = new Schema({
    user_login: {
        type: String,
        require: true,
    },
    user_password: {
        type: String,
        require: true,
    },

    user_nickname: {
        type: String,
       
    },

    user_email: {
        type: String,
        require: true,
        unique:true,
    },

    user_displayname: {
        type: String,
    },

    user_image: {
        type: String,
     },

     user_token: {
        type: String,
       
     },
     
     user_loginstatus: {
        type: Boolean,
         default:false
       
     },


     user_register: {
        type: Date,
        default: Date.now,
     }
});

module.exports = mongoose.model("wp_user", Userregister);