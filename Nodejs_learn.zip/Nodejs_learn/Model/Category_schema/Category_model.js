const mongoose_cat = require("mongoose");
const Schema_category = mongoose_cat.Schema;
const category_result = new Schema_category({
    category_name: {
        type: String,
        require: true,
    },
    category_slug: {
        type: String,
        require: true,
        unique:true,
      
    },

    category_descrption: {
        type: String
       
    },

    category_parent: {
        type: String
      
    },

    category_register: {
        type: Date,
        default: Date.now,
     }
    

    
});

module.exports = mongoose_cat.model("wp_category", category_result);