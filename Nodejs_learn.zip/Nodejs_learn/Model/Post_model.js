const mongoose = require("mongoose");
const post = mongoose.Schema({
  
  
    title:String,
    description:String,
    category:String,
    post_date:Date,
    author: Number,
    post_img:String,


})
module.exports = mongoose.model("Post", post);