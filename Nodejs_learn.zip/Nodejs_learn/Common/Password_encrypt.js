


const passwordencrypt = async(saltround, password)=>{

    const encrypt = await 

    return encrypt;


}

module.exports = passwordencrypt;