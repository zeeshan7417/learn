
const fs = require('fs')

fs.readFile('./Common/NEWS18_gossip_cms_data_2020.json', 'utf8' , (err, data) => {
  if (err) {
    console.error(err)
    return
  }
  console.log(data)
})


fs.writeFile('./Common/NEWS18_gossip_cms_data_2020.json', {'age':299}, (err,data)=>{

console.log('data write here ');
})

