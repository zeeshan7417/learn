const express = require('express');
const router = express.Router();
const cotroller = require('../Controller/Category/Category_controller');

router.get('/category', cotroller.fetchcategory);
router.get('/categorysingle/:id', cotroller.getsinglecategory);
router.post('/addcategory', cotroller.category_save);
router.put('/updatecategory/:id',cotroller.categoryupdate);
router.delete('/delcategory', (req,res)=>{
console.log('delcategory section ');
    
})
module.exports = router;