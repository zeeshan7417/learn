const express = require('express');
const router = express.Router();
router.use(express.static(__dirname + "./public"));
const imageupload = require('../Controller/Imageupload');
const users = require('../Model/User_register_schema');
const bcrypt_data = require('bcryptjs');
const saltround = 10;
const login = require('../Controller/User_login_controller');


router.post('/userlogin',  login.login );


router.post('/usersave', imageupload.single('user_image'), async (req, res, next) => {
    try {

      // console.log();
        const user = await users.findOne({ user_email: req.body.user_email });
        if (user) {

            return res.status(400).json({ email: 'User Email Exist In Databse' });
        }
        else {

               const password = req.body.user_password;
              const haspassword = await bcrypt_data.hash(password,saltround);
                 const newuser = new users({
                user_login: req.body.user_login,
                
                user_password: haspassword,
                user_nickname: req.body.user_nickname,
                user_email: req.body.user_email,
                user_displayname: req.body.user_displayname,
                user_image: req.file.filename,
              
            });

            newuser.save();
            return res.status(200).json({ msg: newuser });
        }


    } catch (error) {

    }
});






module.exports = router;