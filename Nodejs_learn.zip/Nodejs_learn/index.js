const conn = require('./Database/Config');
const express = require("express");
const app = express();

  
const PORT = 8080;

var bodyParser = require('body-parser')
const routers = require('./Router/Router');
const Mainroutes = require('./Router/Mainroute');



app.use(bodyParser.json({ limit: '30mb', extended: true }))
app.use(bodyParser.urlencoded({ extended: true }))
app.use('/', routers);
app.use('/',Mainroutes );

// app.post("/post", (req, res) => {
//   console.log("Connected to React");
// // console.log(req);
// });




  

const users = {};

// app.get('/', (req, res) => {
//     res.sendFile(__dirname + '/public/index.html');
//   });
  
// io.on('connection', (socket) => {
//     socket.on('new-user', name=>{

//         users[socket.id]=name;
//         socket.broadcast.emit('user-conected', name);
//     });
   
//   socket.on('chat message', (msg) => {
//     io.emit('chat message', msg);
//   });

//    socket.on('disconnect', (users)=>{

//      io.emit('chat message',  ' user has been deiconected');
//    })

// });

  
 
app.listen(PORT, console.log(`Server started on port ${PORT}`));
